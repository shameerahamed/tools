angular.module('sbAdminApp.services',['ngResource']).factory('Customer', ['$resource', function ($resource) {
    //$resource() function returns an object of resource class
    return $resource(
            '/stocker/customer/:id', 
            {id: '@custId'},
            {
                update: {
                      method: 'PUT' // To send the HTTP Put request when calling this custom update method.
                }
                 
            }
    );
}]);