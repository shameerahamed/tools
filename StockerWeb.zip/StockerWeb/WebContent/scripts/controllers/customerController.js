'use strict';
 
angular.module('sbAdminApp.controllers', []).controller('customerController', 
		['$scope', '$state', '$stateParams', 'AlertService', 'Customer',                                                                                
		 function($scope, $state, $stateParams, AlertService, Customer) {
			
          var self = this;
          self.customer= new Customer();
           
          self.customers=[];
               
          self.fetchAllcustomers = function(){
              self.customers = Customer.query();
          };
            
          self.createCustomer = function(){
              self.customer.$save(function(){
            	  self.reloadList();
            	  self.reset();
            	  AlertService.add('success', 'Record created Successfully', 5000);
              }, function(err){
            	  console.log(err);
            	  AlertService.add('danger', 'Error in Processing ur request, Pls try again !', 10000);
              });
          };
           
          self.updateCustomer = function(){
              self.customer.$update(function(){
            	  self.reloadList();
            	  AlertService.add('success', 'Record updated successfully', 5000);
              }, function(err){
            	  console.log(err);
            	  AlertService.add('danger', 'Error in Processing ur request, Pls try again !', 5000);
              });
          };
 
         self.deleteCustomer = function(identity){
             var customer = Customer.get({id:identity}, function() {
                  customer.$delete(function(){
                      console.log('Deleting customer with id ', identity);
                      self.reloadList();
                      AlertService.add('success', 'Record deleted successfully', 5000);
                  }, 
                  function(err){
             	  	console.log(err);
               	  	AlertService.add('danger', 'Error in Processing ur request, Pls try again !', 5000);
                 });
             });
          };
                    
          self.fetchCustomer = function(identity) {
        	var customer = Customer.get({id:identity});
        	self.customer = customer;
          };
 
          self.submit = function() {
              if(self.customer.custId==null){
                  console.log('Saving New customer', self.customer);    
                  self.createCustomer();
              }else{
                  console.log('Upddating customer with id ', self.customer.custId);
                  self.updateCustomer();
                  console.log('customer updated with id ', self.customer.custId);
              }
          };
               
          $scope.edit = function(){  
        	  var id = $stateParams.custId;
        	  console.log('id to be edited', id);
        	  self.fetchCustomer(id);
          };
               
          self.remove = function(id){
              console.log('id to be deleted', id);
              if(self.customer.custId === id) {//If it is the one shown on screen, reset screen
                 self.reset();
              }
              self.deleteCustomer(id);
          };
 
           
          self.reset = function(){
              self.customer= new Customer();
              if ($scope.custForm) {
            	  $scope.custForm.$setPristine(); //reset Form
                  $scope.formData = {};
              }
          };
          
          self.reloadList = function() {
        	  self.fetchAllcustomers();
        	  $state.go("dashboard.customers");
        	  self.reset();
          }
          
          $scope.init = function(){
              self.fetchAllcustomers();
              self.reset();
              //  Calling routeParam method
              if ($state.current.method !== undefined) {
                $scope[$state.current.method]();
              }
            };

            $scope.init();
 
      }]);