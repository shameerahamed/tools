'use strict';

App.controller('CustomerController', ['$scope', 'Customer', function($scope, Customer) {
          var self = this;
          self.customer= new Customer();
          
          self.customers=[];
              
          self.fetchAllCustomers = function(){
        	  self.customers = Customer.query();
          };
           
          self.createCustomer = function(){
        	  self.customer.$save(function(){
        		  self.fetchAllCustomers();
        	  });
          };
		  
          self.updateCustomer = function(){
        	  self.customer.$update(function(){
    			  self.fetchAllCustomers();
    		  });
          };

         self.deleteCustomer = function(identity){
        	 var customer = Customer.get({id:identity}, function() {
        		  customer.$delete(function(){
        			  console.log('Deleting customer with id ', identity);
        			  self.fetchAllCustomers();
        		  });
        	 });
          };

          self.fetchAllCustomers();

          self.submit = function() {
              if(self.customer.custId==null){
                  console.log('Saving New Customer', self.customer);    
                  self.createCustomer();
              }else{
    			  console.log('Updating customer with id ', self.customer.custId);
                  self.updateCustomer();
                  console.log('Customer updated with id ', self.customer.custId);
              }
              self.reset();
          };
              
          self.edit = function(id){
              console.log('id to be edited', id);
              for(var i = 0; i < self.customers.length; i++){
                  if(self.customers[i].custId === id) {
                     self.customer = angular.copy(self.customers[i]);
                     break;
                  }
              }
          };
              
          self.remove = function(id){
              console.log('id to be deleted', id);
              if(self.customer.custId === id) {//If it is the one shown on screen, reset screen
                 self.reset();
              }
              self.deleteCustomer(id);
          };

          
          self.reset = function(){
              self.customer= new Customer();
              $scope.myForm.$setPristine(); //reset Form
          };

      }]);
