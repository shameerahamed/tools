'use strict';


App.factory('Customer', ['$resource', function ($resource) {
	//$resource() function returns an object of resource class
    return $resource(
    		'/stocker/customer/:id', 
    		{id: '@custId'},
    		{
    			update: {
    				  contentType: "application/json",
    			      method: 'PUT' // To send the HTTP Put request when calling this custom update method.
    			}
    			
    		}
    );
}]);